"""训练前后对比：读 baseline + 各 post probe，打印三方对比表与样例对照。

运行：
  python compare.py

会自动读 outputs/baseline_probe.json 和 outputs/post_train_probe*.json
（从零版、TRL 版各一份，文件名以 post_train_probe 开头即可）。
输出：格式率 / greedy正确率(pass@8 用 loose 口径) 的三方对比表 + 训练集内难度样例对照。
"""
import json
from pathlib import Path

ROOT = Path(__file__).parent
OUT = ROOT / "outputs"

LEVELS = [
    "L1_add_1digit", "L2_addsub_2digit", "L3_addsub_3digit",
    "L4_mul_1digit", "L5_mul_2x1digit", "L6_mul_2x2digit",
]
TRAINED = {"L2_addsub_2digit", "L3_addsub_3digit", "L5_mul_2x1digit"}


def load(name):
    p = OUT / name
    if p.exists():
        return name.replace("post_train_probe", "").replace(".json", "").strip("_") or "post", json.load(open(p, encoding="utf-8"))
    return None


def main():
    base = json.load(open(OUT / "baseline_probe.json", encoding="utf-8"))
    posts = []
    for f in sorted(OUT.glob("post_train_probe*.json")):
        label = f.name.replace("post_train_probe", "").replace(".json", "").strip("_") or "post"
        posts.append((label, json.load(open(f, encoding="utf-8"))))

    if not posts:
        print("未找到 post_train_probe*.json，请先跑 probe.py 评估训练后模型。")
        return

    reports = [("基线", base)] + posts
    header = f"{'难度':<20}{'训练集':^6}" + "".join(
        f"{name + ' 格式/正确/p@8':^30}" for name, _ in reports
    )
    rows = []
    for lv in LEVELS:
        row = f"{lv:<20}{'√' if lv in TRAINED else '—':^6}"
        for _, rep in reports:
            r = rep[lv]
            row += f"{r['greedy_format_rate']:.2f}/{r['greedy_loose_acc']:.2f}/{r['loose_pass@8']:.2f}".center(30)
        rows.append(row)

    print("=" * 110)
    print("训练前后对比（同评估集 seed=42，50题/难度；格式率 / greedy正确率 / pass@8）")
    print("=" * 110)
    print(header)
    print("\n".join(rows))

    # 训练集内难度样例对照（基线 vs 第一个 post）
    print("\n" + "=" * 110)
    print("样例对照（greedy 解码，基线 vs", posts[0][0], "）")
    print("=" * 110)
    for lv in ["L2_addsub_2digit", "L3_addsub_3digit", "L5_mul_2x1digit"]:
        print(f"\n--- {lv} ---")
        for eb, ep in zip(base[lv]["examples"], posts[0][1][lv]["examples"]):
            print(f"  {eb['expr']} = {eb['answer']}")
            print(f"    前: {eb['greedy_output']!r}")
            print(f"    后: {ep['greedy_output']!r}")


if __name__ == "__main__":
    main()
