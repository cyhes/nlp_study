"""复合规则奖励（可验证奖励 RLVR 的核心）。

reward = 正确分(1.0)  +  格式分(0.2)

  - 正确分用「宽松解析」：基线模型完全不输出 <answer> 标签，若严格要求标签内数字，
    正确信号也是 0 → 组内全零 → advantage 全 0 → 冷启动训不起来。
    宽松解析（取输出最后一个数字）保证一开始就有正确梯度。
  - 格式分(0.2) 故意小于正确分(1.0)：制造「主次信号竞争」。
    训练曲线里你会看到格式分涨得慢——因为组内归一化下 0.2 的增量
    被 1.0 的正确性方差稀释（这正是 reward shaping 的教学点）。

两个函数分开返回，方便训练时分别记录曲线、最后求和。
"""
from data import parse_output


def reward_correct(texts, answers):
    """正确分：宽松解析，最后一个数字正确给 1.0，否则 0.0。"""
    out = []
    for t, a in zip(texts, answers):
        out.append(1.0 if parse_output(t, int(a))[2] else 0.0)
    return out


def reward_format(texts):
    """格式分：输出含 <answer>数字</answer> 给 0.2，否则 0.0（与正确性解耦）。"""
    return [0.2 if parse_output(t, 0)[0] else 0.0 for t in texts]
