"""
从零实现 GRPO（Group Relative Policy Optimization）—— 课程作业仿写版（核心）

不依赖 trl，直接基于 transformers + torch 复现 GRPO 的算法逻辑。
目标：用可验证规则奖励，把 Qwen2-0.5B-Instruct 的算术能力提起来。

每个优化步的流程（= GRPO 的全部逻辑）：
  1. 取 B 个 prompt，每个采样 K 条 completion（temperature=1.0 保证组内多样性）
  2. 规则奖励给每条 completion 打分 r
  3. 同一 prompt 的 K 条做「组内归一化」：
         A_i = (r_i - mean(r)) / (std(r) + 1e-6)
     —— 用组内方差替代价值网络，这是 GRPO 区别于 PPO 的核心
     —— 全对/全错的组 std=0 → A=0 → 不产生梯度（纯浪费算力）
  4. 重算每条 completion 在当前策略下的 logp(new)，与更新前 logp(old) 求 ratio
  5. 裁剪代理损失（PPO-clip 形式）：
         ratio   = exp(logp_new - logp_old)
         loss    = -mean( min(ratio*A, clip(ratio, 1-eps, 1+eps)*A) )
  6. beta=0：不加 KL 项 → 不加载参考模型，省 ~1GB 显存

工程注意（与课程原项目一致的关键坑）：
  - 必须显式 bfloat16 加载（本地 config 若写 fp16，AdamW 的 eps=1e-8 会下溢训废模型）
  - 关掉 gradient checkpointing（transformers 5.x 下它会让 generate 输出乱码）
  - 本脚本需在有 CUDA + 模型的机器运行；编写环境无 GPU，未实跑验证

运行：
  python grpo_from_scratch.py                 # 完整 200 步
  python grpo_from_scratch.py --max_steps 3   # 冒烟测试
"""
import os

os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import argparse
import random
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from data import SYSTEM_PROMPT, make_problem, LEVELS
from rewards import reward_correct, reward_format

ROOT = Path(__file__).parent
MODEL_PATH = Path(r"D:\badou\八斗课程\pretrain_models\Qwen2-0.5B-Instruct")
OUT_DIR = ROOT / "outputs"

# 训练集难度配比：依据基线摸底（probe.py）的 informative group rate 选甜区难度。
# L3/L5 的组内有对有错比例高（0.66~0.76），L2 保底；L1/L4/L6 留作泛化评估。
LEVEL_MIX = [
    ("L3_addsub_3digit", 0.50),
    ("L5_mul_2x1digit", 0.25),
    ("L2_addsub_2digit", 0.25),
]


def build_dataset(n: int, seed: int):
    """程序化生成训练集：prompt 为 chat 格式，answer 供奖励函数使用。"""
    rng = random.Random(seed)
    rows = []
    for _ in range(n):
        r, acc, level = rng.random(), 0.0, LEVEL_MIX[-1][0]
        for lv, p in LEVEL_MIX:
            acc += p
            if r <= acc:
                level = lv
                break
        expr, ans = make_problem(level, rng)
        rows.append(
            {
                "prompt": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": f"计算：{expr} = ?"},
                ],
                "answer": ans,
            }
        )
    return rows


@torch.no_grad()
def generate_batch(model, tokenizer, prompt_texts, K, max_new):
    """每个 prompt 采样 K 条 completion。

    返回：full(生成序列, B*K×L)、attn_full、comp_mask（completion 位置为 1）、prompt_len。
    generate 把新 token 接在整段 input_ids（长度 prompt_len）之后，
    所以 completion 从位置 prompt_len 开始。
    """
    tok = tokenizer(
        prompt_texts, return_tensors="pt", padding=True, truncation=True, max_length=128
    )
    input_ids = tok.input_ids.to(model.device)
    attn = tok.attention_mask.to(model.device)
    prompt_len = input_ids.shape[1]

    out = model.generate(
        input_ids=input_ids,
        attention_mask=attn,
        max_new_tokens=max_new,
        do_sample=True,
        temperature=1.0,
        top_p=1.0,
        num_return_sequences=K,
        pad_token_id=tokenizer.pad_token_id,
    )
    full = out  # (B*K, prompt_len + new)
    seq_len = full.shape[1]
    pad = tokenizer.pad_token_id
    attn_full = (full != pad).long()
    pos = torch.arange(seq_len, device=model.device).unsqueeze(0).expand_as(full)
    comp_mask = (pos >= prompt_len) & (full != pad)
    return full, attn_full, comp_mask, prompt_len


def completion_logprobs(model, full_ids, attn_full, comp_mask):
    """计算每条 completion 在『当前策略』下的对数概率之和（仅 completion 位置）。"""
    logits = model(input_ids=full_ids, attention_mask=attn_full).logits
    logits = logits[:, :-1, :]                       # 预测下一个 token
    targets = full_ids[:, 1:]                        # (B*K, L-1)
    logp = torch.log_softmax(logits.float(), dim=-1)
    tok_logp = logp.gather(2, targets.unsqueeze(-1)).squeeze(-1)
    comp = comp_mask[:, 1:].float()                  # 对齐到 targets（右移一位）
    return (tok_logp * comp).sum(dim=1)              # (B*K,)


def group_advantages(rewards, K):
    """组内归一化得到 advantage。rewards 为长度 B*K 的扁平列表，按 K 分组。"""
    adv = []
    for g in range(0, len(rewards), K):
        grp = rewards[g : g + K]
        m = sum(grp) / len(grp)
        var = sum((x - m) ** 2 for x in grp) / len(grp)
        sd = var ** 0.5
        if sd < 1e-6:                               # 全对或全错：无学习信号
            adv.extend([0.0] * len(grp))
        else:
            adv.extend([(x - m) / sd for x in grp])
    return torch.tensor(adv, dtype=torch.float32, device="cuda")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--max_steps", type=int, default=200, help="优化步数")
    ap.add_argument("--b", type=int, default=4, help="每步 prompt 数（每步共 b*K 条 completion）")
    ap.add_argument("--K", type=int, default=8, help="组内采样数")
    ap.add_argument("--lr", type=float, default=2e-6, help="学习率")
    ap.add_argument("--max_new", type=int, default=64, help="最大生成长度")
    args = ap.parse_args()

    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "left"                 # 批量生成需左 padding

    model = AutoModelForCausalLM.from_pretrained(
        MODEL_PATH, torch_dtype=torch.bfloat16, device_map="cuda"
    )
    model.eval()                                    # eval 模式：关闭 dropout，且仍能反传梯度
    for p in model.parameters():
        p.requires_grad_(True)

    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr)
    K, B = args.K, args.b

    # 预生成整个训练集（GRPO 是在线采样，题目重复无所谓）
    dataset = build_dataset(1000, seed=123)

    for step in range(args.max_steps):
        batch = random.sample(dataset, B)
        prompt_texts, answers = [], []
        for d in batch:
            prompt_texts.append(
                tokenizer.apply_chat_template(
                    d["prompt"], tokenize=False, add_generation_prompt=True
                )
            )
            answers.append(d["answer"])

        # 1) 采样 K 条 completion
        full, attn_full, comp_mask, prompt_len = generate_batch(
            model, tokenizer, prompt_texts, K, args.max_new
        )
        comp_ids = full[:, prompt_len:]
        comp_texts = tokenizer.batch_decode(comp_ids, skip_special_tokens=True)

        # 2) 规则奖励（answers 按 K 平铺，与 completion 顺序一致）
        rc = reward_correct(comp_texts, answers * K)
        rf = reward_format(comp_texts)
        rewards = [c + f for c, f in zip(rc, rf)]

        # 3) 组内归一化 advantage
        advantages = group_advantages(rewards, K)

        # 4) 更新前 logp(old)
        with torch.no_grad():
            old_lp = completion_logprobs(model, full, attn_full, comp_mask).detach()

        # 5) 当前策略 logp(new) + 裁剪代理损失
        new_lp = completion_logprobs(model, full, attn_full, comp_mask)
        ratio = torch.exp(new_lp - old_lp)
        unclipped = ratio * advantages
        clipped = torch.clamp(ratio, 1 - 0.2, 1 + 0.2) * advantages
        loss = -torch.min(unclipped, clipped).mean()

        # 6) 反向 + 更新
        loss.backward()
        optimizer.step()
        optimizer.zero_grad()

        if step % 5 == 0:
            mean_r = sum(rewards) / (B * K)
            print(
                f"step {step:>3}  loss={loss.item():.3f}  "
                f"reward={mean_r:.3f}  ratio_mean={ratio.mean().item():.3f}"
            )

    ckpt = OUT_DIR / "grpo_ckpt_scratch"
    ckpt.mkdir(parents=True, exist_ok=True)
    model.save_pretrained(str(ckpt))
    tokenizer.save_pretrained(str(ckpt))
    peak_gb = torch.cuda.max_memory_allocated() / 1024 ** 3
    print(f"\n训练完成。checkpoint: {ckpt}  GPU 峰值: {peak_gb:.2f} GB")


if __name__ == "__main__":
    main()
