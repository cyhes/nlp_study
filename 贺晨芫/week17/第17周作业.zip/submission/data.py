"""算术题数据生成（与课程作业一致的 6 个难度级别）。

本文件被训练脚本与评估脚本共用：
  - make_problem   : 按难度级别程序化生成一道题 (表达式, 标准答案)
  - parse_output   : 解析模型输出，返回 (格式正确?, 严格正确?, 宽松正确?)
  - build_prompt_texts : 把题目拼成 chat 模板文本

难度旋钮是 GRPO 的关键：选题要让「组内 0<正确数<K」的比例足够高，
否则全对/全错的组 advantage=0，训不出梯度（见 train 脚本）。
"""
import random
import re

SYSTEM_PROMPT = (
    "你是一个算术助手。用户会给你一道算术题，请计算出结果，"
    "并把最终答案放在 <answer> 标签中，例如 <answer>42</answer>。"
    "不要输出其他内容。"
)

TAG_RE = re.compile(r"<answer>\s*(-?\d+)\s*</answer>")
NUM_RE = re.compile(r"-?\d+")

# 从易到难：个位数加法 → 两位数乘法
LEVELS = [
    "L1_add_1digit",       # 个位数加法（太易，不进训练集，留作 sanity check）
    "L2_addsub_2digit",    # 两位数加减
    "L3_addsub_3digit",    # 三位数加减
    "L4_mul_1digit",       # 表内乘法
    "L5_mul_2x1digit",     # 两位数 × 一位数
    "L6_mul_2x2digit",     # 两位数 × 两位数（太难，验证超能力边界学不动）
]


def make_problem(level: str, rng: random.Random):
    """按难度生成一道题，返回 (表达式文本, 标准答案)。"""
    if level == "L1_add_1digit":
        a, b = rng.randint(1, 9), rng.randint(1, 9)
        return f"{a} + {b}", a + b
    if level == "L2_addsub_2digit":
        a, b = rng.randint(10, 99), rng.randint(10, 99)
        if rng.random() < 0.5:
            return f"{a} + {b}", a + b
        a, b = max(a, b), min(a, b)          # 保证减法非负
        return f"{a} - {b}", a - b
    if level == "L3_addsub_3digit":
        a, b = rng.randint(100, 999), rng.randint(100, 999)
        if rng.random() < 0.5:
            return f"{a} + {b}", a + b
        a, b = max(a, b), min(a, b)
        return f"{a} - {b}", a - b
    if level == "L4_mul_1digit":
        a, b = rng.randint(2, 9), rng.randint(2, 9)
        return f"{a} × {b}", a * b
    if level == "L5_mul_2x1digit":
        a, b = rng.randint(10, 99), rng.randint(3, 9)
        return f"{a} × {b}", a * b
    if level == "L6_mul_2x2digit":
        a, b = rng.randint(10, 99), rng.randint(10, 99)
        return f"{a} × {b}", a * b
    raise ValueError(level)


def parse_output(text: str, answer: int):
    """解析模型输出，返回 (格式正确?, 严格正确?, 宽松正确?)。

    格式正确：输出含 <answer>数字</answer>
    严格正确：标签内数字 == answer
    宽松正确：有标签取标签内最后一个数字，无标签取整段输出最后一个数字
              —— 基线模型不输出标签，宽松解析保证冷启动也有正确信号
    """
    m = TAG_RE.search(text)
    fmt_ok = m is not None
    strict_ok = fmt_ok and int(m.group(1)) == answer
    nums = NUM_RE.findall(text)
    loose_ok = bool(nums) and int(nums[-1]) == answer
    return fmt_ok, strict_ok, loose_ok


def build_prompt_texts(tokenizer, problems):
    """把 (表达式, 答案) 列表拼成 chat 模板文本列表。"""
    texts = []
    for expr, _ in problems:
        msgs = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"计算：{expr} = ?"},
        ]
        texts.append(
            tokenizer.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
        )
    return texts
