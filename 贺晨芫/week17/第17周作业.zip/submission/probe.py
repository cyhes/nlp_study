"""基线摸底 / 训练后评估（同一脚本，--model 切换）。

指标：
  - greedy 正确率 / 格式遵循率：测「确定性能力」
  - pass@K（温度采样 K 条，至少一条对）：测「采样多样性带来的上限」
  - informative group rate：组内有对有错的比例 —— GRPO 可学习性的核心指标

运行：
  python probe.py                              # 基线摸底（6 难度 × 50 题，K=8）
  python probe.py --model outputs/grpo_ckpt_scratch --out outputs/post_train_probe.json --seed 42
  python probe.py --model outputs/grpo_ckpt_trl --out outputs/post_train_probe_trl.json --seed 42
必须保持 --seed 42 与基线一致，保证前后评估题完全相同，可配对比较。
"""
import argparse
import json
import random
import time
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from data import SYSTEM_PROMPT, make_problem, LEVELS, parse_output, build_prompt_texts

ROOT = Path(__file__).parent
MODEL_PATH = Path(r"D:\badou\八斗课程\pretrain_models\Qwen2-0.5B-Instruct")
OUT_PATH = ROOT / "outputs" / "baseline_probe.json"


@torch.no_grad()
def generate(model, tokenizer, texts, do_sample, k=1, batch_size=16, max_new=64):
    all_outputs = []
    for i in range(0, len(texts), batch_size):
        batch = texts[i : i + batch_size]
        enc = tokenizer(batch, return_tensors="pt", padding=True).to(model.device)
        out = model.generate(
            **enc,
            max_new_tokens=max_new,
            do_sample=do_sample,
            temperature=1.0 if do_sample else None,
            top_p=1.0 if do_sample else None,
            num_return_sequences=k if do_sample else 1,
            pad_token_id=tokenizer.pad_token_id,
        )
        gen = out[:, enc["input_ids"].shape[1] :]
        decoded = tokenizer.batch_decode(gen, skip_special_tokens=True)
        if do_sample:
            all_outputs.extend(decoded[j * k : (j + 1) * k] for j in range(len(batch)))
        else:
            all_outputs.extend(decoded)
    return all_outputs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true", help="每难度只跑 10 题，快速验证")
    ap.add_argument("--n", type=int, default=50)
    ap.add_argument("--k", type=int, default=8)
    ap.add_argument("--model", type=str, default=str(MODEL_PATH), help="基座或 checkpoint 路径")
    ap.add_argument("--out", type=str, default=str(OUT_PATH))
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()
    n = 10 if args.quick else args.n

    tokenizer = AutoTokenizer.from_pretrained(args.model)
    tokenizer.padding_side = "left"
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    if (Path(args.model) / "adapter_config.json").exists():
        from peft import PeftModel
        base = AutoModelForCausalLM.from_pretrained(MODEL_PATH, torch_dtype=torch.bfloat16, device_map="cuda")
        model = PeftModel.from_pretrained(base, args.model)
    else:
        model = AutoModelForCausalLM.from_pretrained(args.model, torch_dtype=torch.bfloat16, device_map="cuda")
    model.eval()

    rng = random.Random(args.seed)
    report = {}

    for level in LEVELS:
        t0 = time.time()
        problems = [make_problem(level, rng) for _ in range(n)]
        texts = build_prompt_texts(tokenizer, problems)

        greedy_outs = generate(model, tokenizer, texts, do_sample=False)
        g_fmt = g_str = g_loose = 0
        for (expr, ans), out in zip(problems, greedy_outs):
            f, s, l = parse_output(out, ans)
            g_fmt += f
            g_str += s
            g_loose += l

        sample_outs = generate(model, tokenizer, texts, do_sample=True, k=args.k)
        s_strict = s_loose = 0
        passk = loose_passk = 0
        mixed = loose_mixed = 0
        for (_, ans), outs in zip(problems, sample_outs):
            res = [parse_output(o, ans) for o in outs]
            ns = sum(r[1] for r in res)
            nl = sum(r[2] for r in res)
            s_strict += ns
            s_loose += nl
            passk += ns > 0
            loose_passk += nl > 0
            mixed += 0 < ns < args.k
            loose_mixed += 0 < nl < args.k

        report[level] = {
            "n": n, "k": args.k,
            "greedy_format_rate": round(g_fmt / n, 4),
            "greedy_strict_acc": round(g_str / n, 4),
            "greedy_loose_acc": round(g_loose / n, 4),
            "sample_strict_acc": round(s_strict / (n * args.k), 4),
            "sample_loose_acc": round(s_loose / (n * args.k), 4),
            f"pass@{args.k}": round(passk / n, 4),
            f"loose_pass@{args.k}": round(loose_passk / n, 4),
            "informative_group_rate": round(mixed / n, 4),
            "loose_informative_group_rate": round(loose_mixed / n, 4),
            "elapsed_sec": round(time.time() - t0, 1),
            "examples": [
                {"expr": expr, "answer": ans, "greedy_output": out}
                for (expr, ans), out in list(zip(problems, greedy_outs))[:3]
            ],
        }
        r = report[level]
        print(
            f"{level:<20} greedy_loose={r['greedy_loose_acc']:.2f} "
            f"fmt={r['greedy_format_rate']:.2f} loose_acc={r['sample_loose_acc']:.2f} "
            f"loose_pass@{args.k}={r[f'loose_pass@{args.k}']:.2f} "
            f"loose_informative={r['loose_informative_group_rate']:.2f} ({r['elapsed_sec']}s)"
        )

    out_path = Path(args.out)
    out_path.parent.mkdir(exist_ok=True, parents=True)
    json.dump(report, open(out_path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    print(f"\n结果已保存：{out_path}")


if __name__ == "__main__":
    main()
