"""
GRPO 训练（TRL 版兜底）—— 课程原项目同款路径，保证能跑出结果。

与 grpo_from_scratch.py 的区别：这里直接调用 trl 的 GRPOTrainer，
把「算法细节」交给库实现；适合想快速复现课程数字、或显存/稳定性优先的场景。
grpo_from_scratch.py 才是「从零复现 GRPO 逻辑」的仿写主体。

关键配置（与作业要求一致）：
  - num_generations=8       组内采样数 K
  - beta=0.0                 不加载参考模型（省显存）
  - temperature=1.0          组内多样性
  - epsilon=0.2              PPO-clip
  - model_init_kwargs bf16   防止 fp16 下溢训废
  - gradient_checkpointing=False  防止 generate 乱码

运行：
  python train_trl.py                  # 完整 200 步
  python train_trl.py --lora           # 显存不够时降级 LoRA
  python train_trl.py --max_steps 3    # 冒烟
"""
import os

os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import argparse
import random
from pathlib import Path
from datasets import Dataset

import trl_compat  # noqa: F401  必须先于 trl 导入，修复 trl 0.21 × transformers 5.x
from trl import GRPOConfig, GRPOTrainer

from data import SYSTEM_PROMPT, make_problem, LEVELS, parse_output
from rewards import reward_correct, reward_format

ROOT = Path(__file__).parent
MODEL_PATH = Path(r"D:\badou\八斗课程\pretrain_models\Qwen2-0.5B-Instruct")
OUT_DIR = ROOT / "outputs"

LEVEL_MIX = [
    ("L3_addsub_3digit", 0.50),
    ("L5_mul_2x1digit", 0.25),
    ("L2_addsub_2digit", 0.25),
]


def build_dataset(n, seed):
    rng = random.Random(seed)
    rows = []
    for _ in range(n):
        r, acc, level = rng.random(), 0.0, LEVEL_MIX[-1][0]
        for lv, p in LEVEL_MIX:
            acc += p
            if r <= acc:
                level = lv
                break
        expr, ans = make_problem(level, rng)
        rows.append(
            {
                "prompt": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": f"计算：{expr} = ?"},
                ],
                "answer": ans,
                "level": level,
            }
        )
    return Dataset.from_list(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--max_steps", type=int, default=200)
    ap.add_argument("--n_prompts", type=int, default=1000)
    ap.add_argument("--lr", type=float, default=2e-6)
    ap.add_argument("--lora", action="store_true")
    ap.add_argument("--tag", type=str, default="")
    args = ap.parse_args()

    suffix = f"_{args.tag}" if args.tag else ""
    ckpt_dir = OUT_DIR / (f"grpo_ckpt_trl_lora{suffix}" if args.lora else f"grpo_ckpt_trl{suffix}")
    log_path = OUT_DIR / (f"train_log_trl_lora{suffix}.json" if args.lora else f"train_log_trl{suffix}.json")

    dataset = build_dataset(args.n_prompts, seed=123)

    peft_config = None
    if args.lora:
        from peft import LoraConfig
        peft_config = LoraConfig(r=16, lora_alpha=32, target_modules=["q_proj", "k_proj", "v_proj", "o_proj"])

    config = GRPOConfig(
        output_dir=str(ckpt_dir),
        model_init_kwargs={"torch_dtype": "bfloat16"},   # 关键：显式 bf16
        num_generations=8,
        beta=0.0,
        epsilon=0.2,
        temperature=1.0,
        max_prompt_length=128,
        max_completion_length=64,
        per_device_train_batch_size=8,
        gradient_accumulation_steps=4,
        learning_rate=args.lr if not args.lora else 2e-4,
        max_steps=args.max_steps,
        bf16=True,
        gradient_checkpointing=False,                     # 关键：关掉
        logging_steps=5,
        save_strategy="no",
        report_to=[],
        seed=42,
    )

    trainer = GRPOTrainer(
        model=str(MODEL_PATH),
        args=config,
        reward_funcs=[reward_correct, reward_format],
        train_dataset=dataset,
        peft_config=peft_config,
    )
    trainer.train()

    ckpt_dir.mkdir(parents=True, exist_ok=True)
    trainer.save_model(str(ckpt_dir))
    trainer.processing_class.save_pretrained(str(ckpt_dir))
    json.dump(trainer.state.log_history, open(log_path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    print(f"\n训练完成。checkpoint: {ckpt_dir}")


if __name__ == "__main__":
    main()
