"""trl 0.21 + transformers 5.x 兼容性修复（必须在 import trl 之前执行）。

问题根因：
  trl 0.21 用了 transformers 私有函数 _is_package_available()，
  transformers 4.x 返回 bool，5.x 改成始终返回 (bool, version) 元组。
  非空元组恒为 truthy → trl 误判 vllm/deepspeed 等都已安装 → import 崩溃。

修复：在 trl 各子模块被导入前，把所有返回元组的 is_*_available() 补丁成真实布尔。
（仅 train_trl.py 用到；grpo_from_scratch.py 不依赖 trl，无需此文件。）
"""
def _patch_trl_availability_flags():
    import trl.import_utils as tiu
    for name in dir(tiu):
        if not (name.startswith("is_") and name.endswith("_available")):
            continue
        fn = getattr(tiu, name)
        if not callable(fn):
            continue
        try:
            val = fn()
        except Exception:
            continue
        if isinstance(val, tuple):
            real = bool(val[0])
            setattr(tiu, name, lambda *a, _r=real, **k: _r)


def _patch_warnings_issued():
    from transformers import PreTrainedModel
    if not hasattr(PreTrainedModel, "warnings_issued"):
        PreTrainedModel.warnings_issued = {}


_patch_trl_availability_flags()
_patch_warnings_issued()
