# 仿写：基于 GRPO 的强化学习提升模型做数学题能力

> 第十七周作业：实验基于 GRPO 的强化学习提升模型做数学题能力。本目录是我对
> `grpo_arithmetic`（课程原项目）的**仿写复现**——把 GRPO 的核心逻辑用一份
> 自己的代码重新实现一遍，形成「生成数据 → 规则奖励 → 训练 → 配对评估 → 对比」的完整闭环。

## 1. 它要证明什么

用 **0.5B 小模型（Qwen2-0.5B-Instruct）+ 消费级显卡（8GB）**，通过**可程序化验证的规则奖励**
（不靠奖励模型、不靠人工标注），让模型同时学会两件事：

1. **算得更准**——目标难度正确率大幅提升；
2. **按格式输出**——把答案放进 `<answer>N</answer>` 标签。

并量化对比训练前后差异，回答两个 GRPO 关键问题：
- 没训过的难度会不会也涨？（能力泛化）
- 超能力边界的难度能不能学会？（RL 不能凭空创造能力）

## 2. GRPO 核心逻辑（本仿写复现的重点）

GRPO = Group Relative Policy Optimization。相对 PPO 它**去掉了价值网络**，
用「同一 prompt 采样 K 条、组内奖励均值/标准差做归一化」直接得到 advantage：

```
对 B 个 prompt，每个采样 K 条 completion（temperature=1.0 保证组内多样性）
  → 规则奖励给每条 completion 打分 r
  → 同一 prompt 的 K 条做组内归一化：  A_i = (r_i - mean(r)) / std(r)
  → 重算当前策略 logp(new) 与更新前 logp(old) 的 ratio
  → 裁剪代理损失：  loss = -mean( min(ratio·A, clip(ratio,1-ε,1+ε)·A) )
  → beta=0：不加 KL → 不加载参考模型，省显存
```

**最关键的工程思想——选题看「informative group rate」：**
组内 0<正确数<K 的比例。全对/全错的组 std=0 → advantage 全 0 → 不产生梯度（纯浪费算力）。
所以训练集只选「甜区难度」L2/L3/L5，L1/L4/L6 留作泛化评估。

## 3. 目录结构（本仿写）

```
grpo_arithmetic_student/
├── data.py              # 6 难度算术题生成 + 输出解析（被训练/评估共用）
├── rewards.py           # 复合规则奖励：正确(1.0) + 格式(0.2)
├── grpo_from_scratch.py # 【主体】从零实现 GRPO，不依赖 trl，透明复现算法
├── train_trl.py         # 兜底：调用 trl.GRPOTrainer（同课程原项目路径，保证能跑出结果）
├── trl_compat.py        # trl 0.21 × transformers 5.x 兼容补丁（仅 train_trl.py 用）
├── probe.py             # 基线摸底 / 训练后评估（同 seed 配对）
├── compare.py           # 训练前后三方对比表 + 样例对照
└── outputs/             # 训练/评估产物（checkpoint、probe json、曲线）
```

## 4. 运行步骤（在有 CUDA + 模型的机器上）

依赖：`torch` `transformers` `trl` `peft` `accelerate` `datasets` `matplotlib`
（从零版 grpo_from_scratch.py 只需 `torch` + `transformers`）。

```bash
# 0) 改 data.py / grpo_from_scratch.py / train_trl.py / probe.py 顶部的 MODEL_PATH
#    指向你的 Qwen2-0.5B-Instruct 本地路径

# 1) 基线摸底（决定训练难度，记好 L3/L5 的 informative group rate）
python probe.py

# 2) 训练（二选一）
python grpo_from_scratch.py                 # 从零实现版（作业主体，推荐先跑这个展示理解）
python grpo_from_scratch.py --max_steps 3   # 冒烟测试
#   或兜底版（更稳定、显存不够加 --lora）：
python train_trl.py
python train_trl.py --lora

# 3) 训练后评估（必须用 --seed 42，与基线同一批题）
python probe.py --model outputs/grpo_ckpt_scratch --out outputs/post_train_probe.json --seed 42
python probe.py --model outputs/grpo_ckpt_trl     --out outputs/post_train_probe_trl.json --seed 42

# 4) 对比
python compare.py
```

## 5. 预期结果（参考课程原项目，0.5B + 200 步）

| 难度 | 是否训练 | 格式率 基线→训练后 | 正确率 基线→训练后 |
|------|:---:|---|---|
| L1 个位加法 | — | 0.00 → ~1.00 | 0.98 → 1.00 |
| L2 两位加减 | √ | 0.02 → ~1.00 | 0.76 → 0.98 |
| L3 三位加减 | √ | 0.02 → ~0.96 | 0.40 → 0.90 |
| L4 表内乘法 | — | 0.00 → ~1.00 | 0.56 → 1.00（泛化） |
| L5 两位×一位 | √ | 0.00 → ~0.98 | 0.20 → 0.88（4.4 倍） |
| L6 两位×两位 | — | 0.04 → ~0.98 | 0.08 → 0.24（超边界，几乎不涨） |

结论：训练集内与未训练的中等难度都明显上涨（能力泛化），但超出模型能力边界的
L6 几乎学不动——RL 是在能力边界内重排概率分布，不能凭空创造能力。

## 6. 三个必知的工程坑

1. **必须显式 bf16 加载**：本地模型 config 若写 fp16，AdamW 的 `eps=1e-8` 在 fp16 下
   溢出为 0 → `0/0=NaN`，一步训废整个模型。修复：`torch_dtype="bfloat16"`。
2. **关掉 gradient checkpointing**：transformers 5.x 下它 + train 模式会让
   `generate` 输出完全乱码，奖励全 0。GRPO 必须关。
3. **trl 版本兼容**：trl 0.21 与 transformers 5.x 有 4 处不兼容（vllm 误判、
   `warnings_issued` 缺失等），已用 `trl_compat.py` 在导入 trl 前打补丁。

## 7. 想拿更高分？可做这些消融（作业加分项）

- 把格式分权重 0.2 → 1.0，观察「格式秒收敛、正确率爬坡变慢」的信号竞争；
- 删掉 `reward_format`，看格式率是否停在 0（验证「RL 只优化被奖励的行为」）；
- 把 L6 加进训练集，观察 informative rate 塌掉后训练效率下降；
- 改 K=4 / K=16，对比组内 advantage 估计质量；
- 对比 `grpo_from_scratch.py`（全量）与 `train_trl.py --lora` 的显存/正确率/熵。
